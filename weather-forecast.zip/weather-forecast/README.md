# WeatherForecast

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.2.2.

Install node JS

npm install -g @angular/cli

To launch server and open browser http://localhost:4200/

ng serve --open


